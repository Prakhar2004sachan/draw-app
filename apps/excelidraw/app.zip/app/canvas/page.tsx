"use client";
import CanvasBoard from "../components/CanvasBoard";
import NavBar from "../components/NavBar";

export default function CanvasBoardMain() {
  return (
    <div className="w-full h-screen bg-[#121212] relative">
      <CanvasBoard />
      <NavBar />
    </div>
  );
}
