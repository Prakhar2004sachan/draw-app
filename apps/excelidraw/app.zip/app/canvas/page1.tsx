"use client";

import React, { useRef, useEffect, useState } from "react";
import { Stage, Layer, Rect, Line, Circle, Ellipse } from "react-konva";
import type { KonvaEventObject } from "konva/lib/Node";
import type Konva from "konva";

// Types
export type ShapeType = "rectangle" | "circle";

type Shape = {
  id: string;
  type: ShapeType;
  x: number;
  y: number;
  width: number;
  height: number;
};

export default function CanvasBoardMain() {
  const stageRef = useRef<Konva.Stage>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [stageWidth, setStageWidth] = useState(500);
  const [stageHeight, setStageHeight] = useState(500);

  const [currentTool, setCurrentTool] = useState<ShapeType>("rectangle");
  const [shapes, setShapes] = useState<Shape[]>([]);
  const [newShape, setNewShape] = useState<Shape | null>(null);

  // Responsive resize
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current && stageRef.current) {
        const width = containerRef.current.offsetWidth;
        const height = containerRef.current.offsetHeight;

        setStageWidth(width);
        setStageHeight(height);

        stageRef.current.batchDraw();
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Zooming
  const handleWheel = (e: KonvaEventObject<"wheel", WheelEvent>) => {
    e.evt.preventDefault();
    const stage = stageRef.current;
    if (!stage) return;

    const oldScale = stage.scaleX();
    const pointer = stage.getPointerPosition();
    if (!pointer) return;

    const mousePointTo = {
      x: (pointer.x - stage.x()) / oldScale,
      y: (pointer.y - stage.y()) / oldScale,
    };
    let direction = e.evt.deltaY > 0 ? 1 : -1;
    if (e.evt.ctrlKey) direction = -direction;

    const scaleBy = 1.3;
    const newScale = direction > 0 ? oldScale * scaleBy : oldScale / scaleBy;

    stage.scale({ x: newScale, y: newScale });
    const newPos = {
      x: pointer.x - mousePointTo.x * newScale,
      y: pointer.y - mousePointTo.y * newScale,
    };
    stage.position(newPos);
    stage.batchDraw();
  };

  // Helper for accurate mouse coords
  const getRelativePointerPosition = (stage: Konva.Stage) => {
    const transform = stage.getAbsoluteTransform().copy();
    transform.invert();
    const pos = stage.getPointerPosition();
    return transform.point(pos);
  };

  // Draw handlers
  const handleMouseDown = () => {
    if (!stageRef.current) return;
    const point = getRelativePointerPosition(stageRef.current);
    setNewShape({
      id: `shape-${Date.now()}`,
      type: currentTool,
      x: point.x,
      y: point.y,
      width: 0,
      height: 0,
    });
  };

  const handleMouseMove = () => {
    if (!newShape || !stageRef.current) return;
    const point = getRelativePointerPosition(stageRef.current);
    const width = point.x - newShape.x;
    const height = point.y - newShape.y;
    setNewShape({ ...newShape, width, height });
  };

  const handleMouseUp = () => {
    if (newShape) {
      setShapes((prev) => [...prev, newShape]);
      setNewShape(null);
    }
  };

  // Render shape
  const renderShape = (shape: Shape) => {
    if (shape.type === "rectangle") {
      return (
        <Rect
          key={shape.id}
          x={shape.x}
          y={shape.y}
          width={shape.width}
          height={shape.height}
          fill="lightblue"
          stroke="black"
          cornerRadius={10}
        />
      );
    }


    if (shape.type === "circle") {
      return (
        <Ellipse
          key={shape.id}
          x={shape.x + shape.width / 2}
          y={shape.y + shape.height / 2}
          radiusX={Math.abs(shape.width) / 2}
          radiusY={Math.abs(shape.height) / 2}
          fill="lightgreen"
          stroke="black"
        />
      );
    }

    return null;
  };

  return (
    <div className="w-full h-screen bg-zinc-100 relative">
      <div className="p-2 flex gap-4 absolute top-15 left-15 z-5">
        <button
          className="border border-blue-500 text-black px-4 py-2 rounded"
          onClick={() => setCurrentTool("rectangle")}
        >
          🟦 Rectangle
        </button>
        <button
          className="border border-green-500 text-black px-4 py-2 rounded"
          onClick={() => setCurrentTool("circle")}
        >
          ⭕ Circle
        </button>
      </div>

      <div ref={containerRef} className="w-full h-full">
        <Stage
          ref={stageRef}
          width={stageWidth}
          height={stageHeight}
          onWheel={handleWheel}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
        >
          <Layer>
            {shapes.map(renderShape)}
            {newShape && renderShape(newShape)}
          </Layer>
        </Stage>
      </div>
    </div>
  );
}
