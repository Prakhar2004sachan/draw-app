// export const useCanvasDrawing = () => {
//   const [shapes, setShapes] = useState<Shape[]>([]);
//   const [newShape, setNewShape] = useState<Shape | null>(null);

//   const startDrawing = (...) => {...}
//   const updateDrawing = (...) => {...}
//   const finishDrawing = () => {...}

//   return {
//     shapes,
//     newShape,
//     startDrawing,
//     updateDrawing,
//     finishDrawing,
//   };
// };
