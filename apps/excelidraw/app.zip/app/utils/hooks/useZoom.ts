"use client";

import Konva from "konva";
import { useEffect, useRef, useState } from "react";

export function useZoom() {
  const isPanning = useRef(false);
  const [spacePressed, setSpacePressed] = useState(false);

  const handleWheel = (
    e: Konva.KonvaEventObject<WheelEvent>,
    stageRef: React.RefObject<Konva.Stage>
  ) => {
    e.evt.preventDefault();
    const stage = stageRef.current;
    if (!stage) return;

    const oldScale = stage.scaleX();
    const pointer = stage.getPointerPosition();
    if (!pointer) return;

    const mousePointTo = {
      x: (pointer.x - stage.x()) / oldScale,
      y: (pointer.y - stage.y()) / oldScale,
    };

    let direction = e.evt.deltaY > 0 ? 1 : -1;
    if (e.evt.ctrlKey) direction = -direction;

    const scaleBy = 1.2;
    const newScale = direction > 0 ? oldScale * scaleBy : oldScale / scaleBy;

    stage.scale({ x: newScale, y: newScale });

    const newPos = {
      x: pointer.x - mousePointTo.x * newScale,
      y: pointer.y - mousePointTo.y * newScale,
    };
    stage.position(newPos);
    stage.batchDraw();
  };

  const enablePanMode = () => setSpacePressed(true);
  const disablePanMode = () => setSpacePressed(false);


  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.code === "Space") enablePanMode();
    };
    const up = (e: KeyboardEvent) => {
      if (e.code === "Space") disablePanMode();
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);

    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  return {
    handleWheel,
  };
}
