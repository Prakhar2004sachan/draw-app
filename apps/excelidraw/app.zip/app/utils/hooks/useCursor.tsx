import React from 'react'

function useCursor() {
  return (
    <div>useCursor</div>
  )
}

export default useCursor