import { create } from "zustand";
import { Shape, ShapeType } from "../utils/shapes/shapeTypes";

type LineType = {
  points: number[];
  tool: ShapeType;
};

type CanvasState = {
  shapes: Shape[];
  lines: LineType[];
  currentTool: ShapeType;
  setCurrentTool: (tool: ShapeType) => void;
  addShape: (shape: Shape) => void;
  updateShape: (updated: Shape) => void;
  setLines: (lines: LineType[]) => void;
  addLine: (line: LineType) => void;
  updateShapeText: (id: string, text: string) => void;
  updateLastLine: (points: number[]) => void;
  isPanning: boolean;
  scale: number;
  stagePosition: { x: number; y: number };
  setIsPanning: (val: boolean) => void;
  setScale: (scale: number) => void;
  setStagePosition: (pos: { x: number; y: number }) => void;
};

export const useCanvasStore = create<CanvasState>((set) => ({
  isPanning: false,
  scale: 1,
  stagePosition: { x: 0, y: 0 },
  setIsPanning: (val) => set({ isPanning: val }),
  setScale: (scale) => set({ scale }),
  setStagePosition: (pos) => set({ stagePosition: pos }),
  shapes: [],
  lines: [],
  currentTool: "selection",
  setCurrentTool: (tool) => set({ currentTool: tool }),
  addShape: (shape) => set((state) => ({ shapes: [...state.shapes, shape] })),
  updateShape: (updatedShape) =>
    set((state) => ({
      shapes: state.shapes.map((s) =>
        s.id === updatedShape.id ? updatedShape : s
      ),
    })),
  setLines: (lines) => set({ lines }),
  addLine: (line) => set((state) => ({ lines: [...state.lines, line] })),
  updateShapeText: (id, text) =>
    set((state) => ({
      shapes: state.shapes.map((shape) =>
        shape.id === id ? { ...shape, text } : shape
      ),
    })),
  updateLastLine: (points) =>
    set((state) => {
      const updatedLines = [...state.lines];
      const lastLine = updatedLines.pop();
      if (lastLine) {
        updatedLines.push({ ...lastLine, points });
      }
      return { lines: updatedLines };
    }),
}));
