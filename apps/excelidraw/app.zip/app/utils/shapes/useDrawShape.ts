import Konva from "konva";
import { useRef } from "react";
import { Shape } from "../shapes/shapeTypes";
import { useCanvasStore } from "../store";

export const useDrawShape = () => {
  const isDrawing = useRef(false);
  const newShapeRef = useRef<Shape | null>(null);

  const { currentTool, lines, addShape, updateShape, updateLastLine, addLine } =
    useCanvasStore();

  const getPointer = (stage: Konva.Stage) => {
    const transform = stage.getAbsoluteTransform().copy().invert();
    const pos = stage.getPointerPosition();
    return pos ? transform.point(pos) : null;
  };

  const handleMouseDown = (stage: Konva.Stage) => {
    if (!stage || currentTool === "selection") return;

    const pointer = getPointer(stage);
    if (!pointer) return;
    console.log(pointer);

    if (currentTool === "freeDraw" || currentTool === "eraser") {
      isDrawing.current = true;
      addLine({ tool: currentTool, points: [pointer.x, pointer.y] });
      return;
    }

    isDrawing.current = true;
    const shape: Shape = {
      id: `Shape-${Date.now()}`,
      type: currentTool,
      x: pointer.x,
      y: pointer.y,
      width: 0,
      height: 0,
      text: currentTool === "text" ? "Your Text Here" : "",
    };
    newShapeRef.current = shape;
    addShape(shape);
  };

  const handleMouseMove = (stage: Konva.Stage) => {
    if (!stage || !isDrawing.current) return;
    if (!isDrawing.current) return;

    const pointer = getPointer(stage);
    if (!pointer) return null;
    console.log(pointer);

    if (currentTool === "freeDraw" || currentTool === "eraser") {
      const lastLine = lines[lines.length - 1];
      if (!lastLine) return;
      updateLastLine([...lastLine.points, pointer.x, pointer.y]);
      return;
    }

    if (!newShapeRef.current) return;

    const updatedShape = {
      ...newShapeRef.current,
      width: pointer.x - newShapeRef.current.x,
      height: pointer?.y - newShapeRef.current.y,
    };
    newShapeRef.current = updatedShape;
    updateShape(updatedShape);
  };

  const handleMouseUp = () => {
    isDrawing.current = false;
    newShapeRef.current = null;
  };

  return { handleMouseDown, handleMouseMove, handleMouseUp };
};
