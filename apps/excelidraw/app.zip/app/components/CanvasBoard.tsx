"use client";
import React, { useRef, useState } from "react";
import { Stage, Layer, Rect, Line, Ellipse, Arrow, Text } from "react-konva";
import { useDrawShape } from "../utils/shapes/useDrawShape";
import { useCanvasStore } from "../utils/store";
import { useZoom } from "../utils/hooks/useZoom";


const CanvasBoard = () => {
  const stageRef = useRef<any>(null);

  const { handleMouseDown, handleMouseMove, handleMouseUp } = useDrawShape();
  const { shapes, lines } = useCanvasStore();
  const { handleWheel } = useZoom();
  const [selectedIds, setSelectedIds] = useState([]);
  const [selectionRectangle, setSelectionRectangle] = useState({
    visible: false,
    x1: 0,
    y1: 0,
    x2: 0,
    y2: 0,
  });

  const isSelecting = useRef(false);
  const transformerRef = useRef();
  const rectRefs = useRef(new Map());

  useEffect(() => {
    if (selectedIds.length && transformerRef.current) {
      // Get the nodes from the refs Map
      const nodes = selectedIds
        .map((id) => rectRefs.current.get(id))
        .filter((node) => node);

      transformerRef.current.nodes(nodes);
    } else if (transformerRef.current) {
      // Clear selection
      transformerRef.current.nodes([]);
    }
  }, [selectedIds]);

  // Click handler for stage
  const handleStageClick = (e) => {
    // If we are selecting with rect, do nothing
    if (selectionRectangle.visible) {
      return;
    }

    // If click on empty area - remove all selections
    if (e.target === e.target.getStage()) {
      setSelectedIds([]);
      return;
    }

    // Do nothing if clicked NOT on our rectangles
    if (!e.target.hasName("rect")) {
      return;
    }

    const clickedId = e.target.id();

    // Do we pressed shift or ctrl?
    const metaPressed = e.evt.shiftKey || e.evt.ctrlKey || e.evt.metaKey;
    const isSelected = selectedIds.includes(clickedId);

    if (!metaPressed && !isSelected) {
      // If no key pressed and the node is not selected
      // select just one
      setSelectedIds([clickedId]);
    } else if (metaPressed && isSelected) {
      // If we pressed keys and node was selected
      // we need to remove it from selection
      setSelectedIds(selectedIds.filter((id) => id !== clickedId));
    } else if (metaPressed && !isSelected) {
      // Add the node into selection
      setSelectedIds([...selectedIds, clickedId]);
    }
  };

  return (
    <Stage
      width={window.innerWidth}
      height={window.innerHeight}
      ref={stageRef}
      onMouseDown={() => handleMouseDown(stageRef.current)}
      onMouseMove={() => handleMouseMove(stageRef.current)}
      onMouseUp={() => handleMouseUp()}
      onWheel={(e) => handleWheel(e, stageRef)}
    >
      <Layer>
        {shapes.map((shape) =>
          shape.type === "rectangle" ? (
            <Rect
              key={shape.id}
              x={shape.x}
              y={shape.y}
              width={shape.width}
              height={shape.height}
              stroke="white"
            />
          ) : shape.type === "ellipse" ? (
            <Ellipse
              key={shape.id}
              x={shape.x + shape.width / 2}
              y={shape.y + shape.height / 2}
              radiusX={Math.abs(shape.width) / 2}
              radiusY={Math.abs(shape.height) / 2}
              stroke="white"
            />
          ) : shape.type === "arrow" ? (
            <Arrow
              key={shape.id}
              points={[
                shape.x,
                shape.y,
                shape.x + shape.width,
                shape.y + shape.height,
              ]}
              closed
              stroke="white"
              fill="white"
              lineCap="round"
              lineJoin="round"
              tension={0.05}
            />
          ) : shape.type === "diamond" ? (
            <Line
              key={shape.id}
              points={[
                shape.x + shape.width / 2,
                shape.y,
                shape.x + shape.width,
                shape.y + shape.height / 2,
                shape.x + shape.width / 2,
                shape.y + shape.height,
                shape.x,
                shape.y + shape.height / 2,
                shape.x + shape.width / 2,
                shape.y,
              ]}
              stroke="white"
              tension={0.05}
            />
          ) : shape.type === "line" ? (
            <Line
              key={shape.id}
              stroke={"white"}
              points={[
                shape.x,
                shape.y,
                shape.x + shape.width,
                shape.y + shape.height,
              ]}
            />
          ) : shape.type === "text" ? (
            <Text
              fill={"white"}
              key={shape.id}
              x={shape.x}
              y={shape.y}
              text={shape.text}
              fontSize={20}
              draggable
            />
          ) : null
        )}
      </Layer>
      <Layer>
        {lines.map((line, i) => (
          <Line
            key={i}
            points={line.points}
            stroke={line.tool === "eraser" ? "#121212" : "white"}
            strokeWidth={line.tool === "eraser" ? 50 : 10}
            tension={0.5}
            lineCap="round"
            globalCompositeOperation={
              line.tool === "eraser" ? "destination-out" : "source-over"
            }
          />
        ))}
      </Layer>
    </Stage>
  );
};

export default CanvasBoard;
